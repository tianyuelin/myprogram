$(function () {
    $('.blueDialog').load('dialog.html');
});